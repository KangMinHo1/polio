package hacktip.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
@Getter
@AllArgsConstructor
public class TokenResponseDto {

    private String accessToken;

}
